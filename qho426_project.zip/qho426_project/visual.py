

from tui import *
import matplotlib.pyplot as plt

"""
This module is responsible for visualising the data using Matplotlib.
"""

"""
Task 22 - 24: Write suitable functions to visualise the data as follows:

- Display a pie chart showing the total number of positive and negative reviews for a specified hotel.
- Display the number of reviews per the nationality of a reviewer. This should by ordered by the number of reviews, highest first, and should show the top 15 + “Other” nationalities.
- Display a suitable animated visualisation to show how the number of positive reviews, negative reviews and the average rating change over time.

Each function should visualise the data using Matplotlib.
"""


def pieChart(reviews=[]):
    hotelName = hotel_name()
    labels = ['Positive Reviews', 'Negative Reviews']
    positiveReviews = 0
    negativeReviews = 0
    for i in range(0, len(reviews)):
        if hotelName == reviews[i][1]:
            if reviews[i][3] == 'No Negative':
                positiveReviews += 1
            elif reviews[i][3] == 'No Positive':
                negativeReviews += 1
            else:
                negativeReviews += 1
                positiveReviews += 1
    sizes = [positiveReviews, negativeReviews]
    fig1, ax = plt.subplots()
    ax.pie(sizes, labels=labels, startangle=90)
    ax.axis('equal')
    ax.set_title(hotelName)
    plt.show()


def nationalityGraph(reviews=[]):
    countries = []
    reviewsCounter = []
    for i in range(1, len(reviews)):
        if reviews[i][2] not in countries:
            countries.append(reviews[i][2])
            reviewsCounter.append(0)
    for i in range(0, len(countries)):
        for j in range(1, len(reviews)):
            if countries[i] == reviews[j][2]:
                reviewsCounter[i] += 1
    for i in range(0, len(countries)):
        for j in range(0, len(countries) - i - 1):
            if reviewsCounter[j] < reviewsCounter[j + 1]:
                reviewsCounter[j], reviewsCounter[j + 1] = reviewsCounter[j + 1], reviewsCounter[j]
                countries[j], countries[j + 1] = countries[j + 1], countries[j]
    sortedCountries = countries
    sortedReviews = reviewsCounter
    if len(countries) > 15:
        othersReviews = sum(reviewsCounter[15:])
        sortedCountries = countries[:15] + ['Others']
        sortedReviews = reviewsCounter[:15] + [othersReviews]
    fig, ax = plt.subplots()
    ax.bar(sortedCountries, sortedReviews)
    ax.set_xlabel('Nation')
    ax.set_ylabel('Number of reviews')
    ax.set_title('Reviews per nation')
    plt.xticks(rotation=90)
    plt.show()


def animationGraph(reviews=[]):
    # Not attempted
    pass
