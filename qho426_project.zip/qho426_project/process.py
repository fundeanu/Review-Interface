from tui import *

"""
This module is responsible for processing the data.  Each function in this module will take a list of reviews,
process it and return the desired result.
"""

"""
Task 16 - 20: Write suitable functions to process the data.

Each of the functions below should follow the pattern:
- Take a list of reviews (where each review is a list of data values) as a parameter.
- Process the list of reviews appropriately.  You may use the module 'tui' to retrieve any additional information 
required from the user to complete the processing.
- Return a suitable result

The required functions are as follows:
- Retrieve the total number of reviews that have been loaded.
- Retrieve the reviews for a hotel where the hotel name is specified by the user.
- Retrieve the reviews for the dates specified by the user.
- Retrieve all the reviews grouped by the reviewer’s nationality.
- Retrieve a summary of all the reviews. This should include the following information for each date in ascending order:
    - the total number of negative reviews on that date
    - the total number of positive reviews on that date
    - the average rating on that date
"""


def numberReviews(reviews=[]):
    print(f'The total number of reviews in the list is {len(reviews)}')


def nameSearch(reviews=[]):
    progress('Search by Hotel Name', 0)
    hotelName = hotel_name()
    for i in reviews:
        if i[1] == hotelName:
            print(i)
    progress('Search by Hotel Name', 100)


def dateSearch(reviews=[]):
    progress('Search by Date', 0)
    date = review_dates()
    for i in date:
        for j in reviews:
            if i == j[0]:
                print(j)
    progress('Search by Date', 100)


def nationalitySearch(reviews=[]):
    progress('Search by Nationality', 0)
    nationality = input("Enter the country of origin: ")
    for i in reviews:
        if nationality == i[2]:
            print(i)
    progress('Search by Nationality', 100)


def dateCompleteSearch(reviews=[]):
    sortedReviews = reviews
    progress('Loading reviews in order', 0)
    for i in range(len(sortedReviews)):
        for j in range(1, len(sortedReviews) - i - 1):
            month1, day1, year1 = sortedReviews[j][0].split("/")
            month2, day2, year2 = sortedReviews[j + 1][0].split("/")
            month1 = int(month1)
            day1 = int(day1)
            year1 = int(year1)
            month2 = int(month2)
            day2 = int(day2)
            year2 = int(year2)
            if year1 > year2:
                sortedReviews[j], sortedReviews[j + 1] = sortedReviews[j + 1], sortedReviews[j]
            elif year1 == year2 and month1 > month2:
                sortedReviews[j], sortedReviews[j + 1] = sortedReviews[j + 1], sortedReviews[j]
            elif year1 == year2 and month1 == month2 and day1 > day2:
                sortedReviews[j], sortedReviews[j + 1] = sortedReviews[j + 1], sortedReviews[j]
    date_list = []
    for i in range(1, len(sortedReviews)):
        if sortedReviews[i][0] not in date_list:
            date_list.append(sortedReviews[i][0])
    for i in range(0, len(date_list)):
        positive_reviews = 0
        negative_reviews = 0
        for j in range(1, len(sortedReviews)):
            if date_list[i] == sortedReviews[j][0] and sortedReviews[j][3] == 'No Negative':
                positive_reviews += 1
            elif date_list[i] == sortedReviews[j][0] and sortedReviews[j][4] == 'No Positive':
                negative_reviews += 1
            elif date_list[i] == sortedReviews[j][0]:
                negative_reviews += 1
                positive_reviews += 1
        print(f'{date_list[i]}: Negative reviews - {negative_reviews}; Positive reviews - {positive_reviews}; Overall rating - ' + str(round((positive_reviews / (positive_reviews + negative_reviews)) * 10, 1)))
    progress('Loading reviews in order', 100)